/* ===== EDIT FILE INI SAJA UNTUK MENGGANTI ISI WEBSITE ===== */

window.SITE = {
  email: "emailkamu@gmail.com",  // <- ganti dengan Gmail kamu
  x: "oxkippo",
  telegram: "oxkippo",
  discord: ""                    // <- isi handle Discord kamu, kosongkan kalau tidak mau ditampilkan
};

/* Karya. Taruh gambar dengan nama di "img" di folder yang sama dengan index.html.
   Kalau file gambar belum ada, tampil seni placeholder otomatis. */
window.KARYA = [
  { code: "A-01", title: "Untitled 01", spec: "Digital art", year: "", img: "art-01.jpg", art: "rings",   seed: 3 },
  { code: "A-02", title: "Untitled 02", spec: "Digital art", year: "", img: "art-02.jpg", art: "grid",    seed: 7 },
  { code: "A-03", title: "Untitled 03", spec: "Digital art", year: "", img: "art-03.jpg", art: "waves",   seed: 11 },
  { code: "A-04", title: "Untitled 04", spec: "Digital art", year: "", img: "art-04.jpg", art: "nodes",   seed: 5 },
  { code: "A-05", title: "Untitled 05", spec: "Digital art", year: "", img: "art-05.jpg", art: "stripes", seed: 9 },
  { code: "A-06", title: "Untitled 06", spec: "Digital art", year: "", img: "art-06.jpg", art: "squares", seed: 2 },
  { code: "A-07", title: "Untitled 07", spec: "Digital art", year: "", img: "art-07.jpg", art: "bars",    seed: 4 },
  { code: "A-08", title: "Untitled 08", spec: "Digital art", year: "", img: "art-08.jpg", art: "rings",   seed: 8 }
];
