(function () {
  var SITE = window.SITE || {};
  var KARYA = window.KARYA || [];
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var $ = function (id) { return document.getElementById(id); };

  /* ---------- Kontak & link ---------- */
  document.querySelectorAll("[data-mail]").forEach(function (a) {
    a.setAttribute("href", "mailto:" + SITE.email);
    if (a.hasAttribute("data-show")) a.textContent = SITE.email;
  });
  document.querySelectorAll("[data-x]").forEach(function (a) {
    a.setAttribute("href", "https://x.com/" + SITE.x);
    if (a.textContent.indexOf("@") === 0) a.textContent = "@" + SITE.x;
  });
  document.querySelectorAll("[data-tg]").forEach(function (a) {
    a.setAttribute("href", "https://t.me/" + SITE.telegram);
    if (a.textContent.indexOf("@") === 0) a.textContent = "@" + SITE.telegram;
  });
  if (SITE.discord) {
    $("discord-row").hidden = false;
    $("discord-handle").textContent = SITE.discord;
  }
  var year = $("year"); if (year) year.textContent = new Date().getFullYear();

  var copyBtn = $("copy-mail");
  if (copyBtn) copyBtn.addEventListener("click", function () {
    var done = function () { copyBtn.textContent = "Tersalin"; setTimeout(function () { copyBtn.textContent = "Salin email"; }, 1800); };
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(SITE.email).then(done, done); else done();
  });

  var form = $("form");
  if (form) form.addEventListener("submit", function (e) {
    e.preventDefault();
    var d = new FormData(form);
    var nama = (d.get("nama") || "").toString().trim();
    var subject = "[" + d.get("topik") + "] " + (nama || "Halo Yuura");
    var body = (d.get("pesan") || "") + "\n\n" + nama + "\n" + (d.get("email") || "");
    window.location.href = "mailto:" + SITE.email + "?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(body);
  });

  /* ---------- Hero: video opsional, kalau tidak ada tampil aliran garis ---------- */
  var hero = document.querySelector(".hero");
  var vid = $("hero-video");
  if (vid) {
    if (reduce) vid.pause();
    vid.addEventListener("loadeddata", function () { hero.classList.add("has-video"); });
  }

  var c = $("flow");
  if (c) {
    var ctx = c.getContext("2d"), w = 0, h = 0, parts = [], mouse = { x: -999, y: -999 }, run = true, t = 0;
    var BG = "14,13,12";

    var spawn = function (p) {
      p.x = Math.random() * w; p.y = Math.random() * h; p.life = 80 + Math.random() * 220;
      return p;
    };
    var init = function () {
      var r = hero.getBoundingClientRect(), dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      w = r.width; h = r.height; c.width = w * dpr; c.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.fillStyle = "rgb(" + BG + ")"; ctx.fillRect(0, 0, w, h);
      var n = Math.round(Math.min(900, Math.max(260, (w * h) / 2200)));
      parts = [];
      for (var i = 0; i < n; i++) { var p = spawn({}); p.blue = i % 5 === 0; parts.push(p); }
    };
    var step = function () {
      t += 16;
      ctx.fillStyle = "rgba(" + BG + ",0.07)"; ctx.fillRect(0, 0, w, h);
      var i, p, a, dx, dy, d, nx, ny;
      for (i = 0; i < parts.length; i++) {
        p = parts[i];
        a = (Math.sin(p.x * 0.0028 + t * 0.00022) + Math.cos(p.y * 0.0036 - t * 0.00016)) * Math.PI * 1.1;
        dx = p.x - mouse.x; dy = p.y - mouse.y; d = Math.sqrt(dx * dx + dy * dy);
        if (d < 150) a += (1 - d / 150) * 2.4;
        nx = p.x + Math.cos(a) * 1.1; ny = p.y + Math.sin(a) * 1.1;
        p.px = p.x; p.py = p.y; p.x = nx; p.y = ny; p.life--;
      }
      for (var pass = 0; pass < 2; pass++) {
        ctx.strokeStyle = pass ? "rgba(94,123,255,0.5)" : "rgba(228,232,242,0.32)";
        ctx.lineWidth = 1; ctx.beginPath();
        for (i = 0; i < parts.length; i++) {
          p = parts[i];
          if (p.blue === !!pass) { ctx.moveTo(p.px, p.py); ctx.lineTo(p.x, p.y); }
        }
        ctx.stroke();
      }
      for (i = 0; i < parts.length; i++) {
        p = parts[i];
        if (p.life < 0 || p.x < 0 || p.x > w || p.y < 0 || p.y > h) spawn(p);
      }
    };
    var loop = function () { if (run) step(); requestAnimationFrame(loop); };

    init();
    window.addEventListener("resize", function () { init(); if (reduce) for (var k = 0; k < 160; k++) step(); });
    var setMouse = function (e) {
      var tt = e.touches ? e.touches[0] : e, r = c.getBoundingClientRect();
      mouse.x = tt.clientX - r.left; mouse.y = tt.clientY - r.top;
    };
    hero.addEventListener("mousemove", setMouse);
    hero.addEventListener("touchmove", setMouse, { passive: true });
    hero.addEventListener("mouseleave", function () { mouse.x = mouse.y = -999; });

    if (reduce) { for (var k = 0; k < 160; k++) step(); }
    else {
      if ("IntersectionObserver" in window) new IntersectionObserver(function (en) { run = en[0].isIntersecting; }).observe(hero);
      requestAnimationFrame(loop);
    }
  }

  /* ---------- Seni placeholder (silver + biru) ---------- */
  function rng(s) {
    return function () {
      s |= 0; s = (s + 0x6D2B79F5) | 0;
      var t = Math.imul(s ^ (s >>> 15), 1 | s);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  var A = "#5E7BFF", B = "#E4E8F2", C = "#8E9BB8";
  var arts = {
    rings: function (r, W, H) {
      var s = "", m = Math.max(W, H);
      for (var i = 0; i < 10; i++) {
        var hot = i % 4 === 0;
        s += '<circle cx="' + (W / 2 + (r() - 0.5) * W * 0.18).toFixed(1) + '" cy="' + (H / 2 + (r() - 0.5) * H * 0.1).toFixed(1) + '" r="' + ((i + 1) * m / 17).toFixed(1) + '" fill="none" stroke="' + (hot ? B : A) + '" stroke-width="' + (hot ? 2 : 1.2) + '" opacity="' + (1 - i * 0.07).toFixed(2) + '"/>';
      }
      return s;
    },
    grid: function (r, W, H) {
      var s = "", st = 44, sz = 34;
      for (var y = 0; y * st < H + st; y++) for (var x = 0; x * st < W + st; x++) {
        var v = r(), col = v > 0.94 ? B : v > 0.6 ? A : C;
        s += '<rect x="' + (8 + x * st) + '" y="' + (8 + y * st) + '" width="' + sz + '" height="' + sz + '" rx="5" fill="' + col + '" opacity="' + (v > 0.94 ? 1 : (0.08 + v * 0.45).toFixed(2)) + '"/>';
      }
      return s;
    },
    waves: function (r, W, H) {
      var s = "";
      for (var i = 0; i < 9; i++) {
        var base = H * 0.15 + i * H * 0.09, amp = H * 0.02 + r() * H * 0.04, ph = r() * 6, d = "M0," + H;
        for (var x = 0; x <= W; x += W / 24) d += " L" + x.toFixed(1) + "," + (base + Math.sin(x / (W * 0.12) + ph) * amp).toFixed(1);
        d += " L" + W + "," + H + " Z";
        s += '<path d="' + d + '" fill="' + (i === 6 ? B : A) + '" opacity="' + (i === 6 ? 0.85 : (0.07 + i * 0.05).toFixed(2)) + '"/>';
      }
      return s;
    },
    nodes: function (r, W, H) {
      var p = [], s = "", i, j, lim = Math.max(W, H) * 0.34;
      for (i = 0; i < 16; i++) p.push([W * 0.06 + r() * W * 0.88, H * 0.06 + r() * H * 0.88]);
      for (i = 0; i < p.length; i++) for (j = i + 1; j < p.length; j++) {
        var dx = p[i][0] - p[j][0], dy = p[i][1] - p[j][1], d = Math.sqrt(dx * dx + dy * dy);
        if (d < lim) s += '<line x1="' + p[i][0].toFixed(1) + '" y1="' + p[i][1].toFixed(1) + '" x2="' + p[j][0].toFixed(1) + '" y2="' + p[j][1].toFixed(1) + '" stroke="' + C + '" stroke-opacity="' + (0.55 * (1 - d / lim)).toFixed(2) + '"/>';
      }
      for (i = 0; i < p.length; i++) s += '<circle cx="' + p[i][0].toFixed(1) + '" cy="' + p[i][1].toFixed(1) + '" r="' + (i % 5 === 0 ? 7 : 4) + '" fill="' + (i % 5 === 0 ? B : C) + '"/>';
      return s;
    },
    stripes: function (r, W, H) {
      var s = "";
      for (var i = -6; i < 22; i++) {
        var hot = i % 7 === 0;
        s += '<rect x="' + (i * W / 14).toFixed(1) + '" y="' + (-H * 0.3) + '" width="' + (4 + r() * W * 0.05).toFixed(1) + '" height="' + (H * 1.6) + '" fill="' + (hot ? B : A) + '" opacity="' + (hot ? 0.9 : (0.15 + r() * 0.5).toFixed(2)) + '" transform="rotate(24 ' + W / 2 + " " + H / 2 + ')"/>';
      }
      return s;
    },
    squares: function (r, W, H) {
      var s = "", m = Math.min(W, H);
      for (var i = 0; i < 9; i++) {
        var z = (i + 1) * m * 0.055 + m * 0.06, hot = i === 8;
        s += '<rect x="' + (W / 2 - z).toFixed(1) + '" y="' + (H / 2 - z).toFixed(1) + '" width="' + (z * 2).toFixed(1) + '" height="' + (z * 2).toFixed(1) + '" rx="' + (i * 2) + '" fill="none" stroke="' + (hot ? B : A) + '" stroke-width="' + (hot ? 2.4 : 1.3) + '" opacity="' + (1 - i * 0.06).toFixed(2) + '" transform="rotate(' + (i * 6 + r() * 4).toFixed(1) + " " + W / 2 + " " + H / 2 + ')"/>';
      }
      return s;
    },
    bars: function (r, W, H) {
      var s = "", n = 11, bw = W / (n * 1.6);
      for (var i = 0; i < n; i++) {
        var hgt = H * 0.2 + i * H * 0.05 + r() * H * 0.1, x = W * 0.05 + i * (W * 0.9 / n), y = H * 0.94 - hgt;
        s += '<rect x="' + x.toFixed(1) + '" y="' + y.toFixed(1) + '" width="' + bw.toFixed(1) + '" height="' + hgt.toFixed(1) + '" rx="4" fill="' + A + '" opacity="' + (0.3 + i * 0.05).toFixed(2) + '"/>';
        s += '<rect x="' + x.toFixed(1) + '" y="' + y.toFixed(1) + '" width="' + bw.toFixed(1) + '" height="6" rx="3" fill="' + B + '"/>';
      }
      return s;
    }
  };

  var gid = 0;
  function paint(el, type, seed, W, H, src) {
    var id = "g" + (gid++);
    el.insertAdjacentHTML("afterbegin",
      '<svg viewBox="0 0 ' + W + " " + H + '" preserveAspectRatio="xMidYMid slice" aria-hidden="true">' +
      '<defs><linearGradient id="' + id + '" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#1B1F2B"/><stop offset="1" stop-color="#0B0B0C"/></linearGradient></defs>' +
      '<rect width="' + W + '" height="' + H + '" fill="url(#' + id + ')"/>' + (arts[type] || arts.rings)(rng(seed * 9973), W, H) + "</svg>");
    if (src) {
      var im = new Image();
      im.onload = function () {
        el.style.backgroundImage = "url(" + src + ")";
        el.classList.add("has-img");
        el.setAttribute("data-loaded", src);
      };
      im.src = src;
    }
  }

  /* Cover kartu build */
  document.querySelectorAll(".build .cover").forEach(function (el) {
    paint(el, el.getAttribute("data-art"), parseInt(el.getAttribute("data-seed") || "1", 10),
      parseInt(el.getAttribute("data-w") || "640", 10), parseInt(el.getAttribute("data-h") || "400", 10), el.getAttribute("data-img"));
  });

  /* ---------- Galeri + lightbox ---------- */
  var gal = $("gal"), items = [];
  KARYA.forEach(function (k, i) {
    var b = document.createElement("button");
    b.type = "button"; b.className = "item";
    b.setAttribute("aria-label", "Lihat " + k.title);
    b.innerHTML = '<div class="cover"><span class="code"></span></div><div class="cap"><h3></h3><span class="yr"></span></div><p class="spec"></p>';
    b.querySelector(".code").textContent = k.code || "";
    b.querySelector("h3").textContent = k.title || "";
    b.querySelector(".yr").textContent = k.year || "";
    b.querySelector(".spec").textContent = k.spec || "";
    paint(b.querySelector(".cover"), k.art, k.seed || i + 1, 400, 500, k.img);
    b.addEventListener("click", function () { openLb(i); });
    gal.appendChild(b); items.push(b);
  });

  var dlg = $("lb"), media = $("lb-media"), cap = $("lb-cap");
  function openLb(i) {
    var k = KARYA[i], cover = items[i].querySelector(".cover"), src = cover.getAttribute("data-loaded");
    media.innerHTML = "";
    if (src) {
      var img = new Image(); img.src = src; img.alt = k.title; media.appendChild(img);
    } else {
      var wrap = document.createElement("div"); wrap.className = "lb-art";
      wrap.appendChild(cover.querySelector("svg").cloneNode(true)); media.appendChild(wrap);
    }
    cap.textContent = [k.code, k.title, k.spec, k.year].filter(Boolean).join(" · ");
    if (dlg.showModal) dlg.showModal();
  }
  $("lb-close").addEventListener("click", function () { dlg.close(); });
  dlg.addEventListener("click", function (e) { if (e.target === dlg) dlg.close(); });
})();
