(function () {
  var year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();

  var el = document.getElementById("typed");
  var count = document.getElementById("count");
  var fill = document.getElementById("meter-fill");
  if (!el) return;

  var text = el.getAttribute("data-text") || el.textContent;

  function render(n) {
    if (count) count.textContent = n;
    if (fill) fill.style.width = Math.min(100, (n / 280) * 100) + "%";
  }

  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (reduce) {
    render(text.length);
    return;
  }

  // Satu gerakan saat halaman dibuka: draft thread diketik sekali.
  el.setAttribute("aria-label", text);
  el.textContent = "";
  el.classList.add("typing");
  var i = 0;
  (function tick() {
    i++;
    el.textContent = text.slice(0, i);
    render(i);
    if (i < text.length) {
      setTimeout(tick, 32);
    } else {
      el.classList.remove("typing");
    }
  })();
})();
